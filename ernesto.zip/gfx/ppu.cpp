/*
    ernesto - 6502, ergo NES emulator
    author: Iago Maldonado (@iagoMAO)
*/

#include "../headers/gfx/ppu.h";
#include <cstdint>

namespace ppu
{
    int ppu_cycle = 0;
    int ppu_scanline = 0;

    uint8_t* ppu_ctrl; // Writable
    uint8_t* ppu_mask; // Writable
    uint8_t* ppu_status; // Read only
    uint8_t* oam_addr; // Writable 
    uint8_t* oam_data; // Writable and readable
    uint16_t* ppu_scroll; // Writable 2x (16-bit)
    uint16_t* ppu_addr; // Writable 2x (16-bit)
    uint8_t* ppu_data; // Writable and readable
    uint8_t* oam_dma; // Writable

    std::vector<uint8_t> pattern_tables(0x2000); // 8192 bytes
    std::vector<uint8_t> nametables(0x1000); // 4096 bytes
    std::vector<uint8_t> mirror(0x0F00); // 3840 bytes
    std::vector<uint8_t> palette(0x20); // 32 bytes

    cpu::CPU* cpu = nullptr;
    uint32_t framebuffer[256 * 240] = { 0 };

    bool frameReady = false;
    bool addrLatch = false;

    const uint32_t nes_palette[64] = {
        0x7C7C7C, 0x0000FC, 0x0000BC, 0x4428BC, 0x940084, 0xA80020, 0xA81000, 0x881400,
        0x503000, 0x007800, 0x006800, 0x005800, 0x004058, 0x000000, 0x000000, 0x000000,
        0xBCBCBC, 0x0078F8, 0x0058F8, 0x6844FC, 0xD800CC, 0xE40058, 0xF83800, 0xE45C10,
        0xAC7C00, 0x00B800, 0x00A800, 0x00A844, 0x008888, 0x000000, 0x000000, 0x000000,
        0xF8F8F8, 0x3CBCFC, 0x6888FC, 0x9878F8, 0xF878F8, 0xF85898, 0xF87858, 0xFCA044,
        0xF8B800, 0xB8F818, 0x58D854, 0x58F898, 0x00E8D8, 0x787878, 0x000000, 0x000000,
        0xFCFCFC, 0xA4E4FC, 0xB8B8F8, 0xD8B8F8, 0xF8B8F8, 0xF8A4C0, 0xF0D0B0, 0xFCE0A8,
        0xF8D878, 0xD8F878, 0xB8F8B8, 0xB8F8D8, 0x00FCFC, 0xF8D8F8, 0x000000, 0x000000
    };

    uint16_t vramAddress = 0;
    uint16_t tempVramAddress = 0;

    void initialize(cpu::CPU& c)
    {
        // todo: better checks later for memory initialization, cpu status, etc
        // PPU registers must point to their respective addresses in memory map
        ppu_ctrl = &memory::ppu[0x00];
        ppu_mask = &memory::ppu[0x01];
        ppu_status = &memory::ppu[0x02];
        oam_addr = &memory::ppu[0x03];
        oam_data = &memory::ppu[0x04];
        ppu_scroll = reinterpret_cast<uint16_t*>(&memory::ppu[0x05]);
        ppu_addr = reinterpret_cast<uint16_t*>(&memory::ppu[0x06]);
        ppu_data = &memory::ppu[0x07];
        oam_dma = &memory::apu[0x14];

        cpu = &c;

        for (int i = 0; i < 32; i++) {
            ppu::palette[i] = i % 64;  // Cycle through palette entries
        }
    }

    void tick()
    {
        frameReady = false;
        ppu_cycle++;

        if (ppu_cycle >= 341) // this line is finished
        {
            ppu_cycle = 0;
            ppu_scanline++;

            if (ppu_scanline == 241)
            {
                // vblank
                *ppu_status |= ppu_status_flags::s_V;
                cpu::NMI(*cpu);

                drawNametable(framebuffer, ppu::pattern_tables.data(), ppu::nametables.data(), ppu::palette.data());
            }
            else if (ppu_scanline >= 261)
            {
                // end of frame
                *ppu_status &= ~ppu_status_flags::s_V;
                ppu_scanline = 0;
                frameReady = true;
            }
        }
    }

    uint8_t read(uint16_t addr)
    {
        uint16_t reg = (addr - 0x2000) % 8;
        uint8_t status = *ppu_status;

        switch (reg)
        {
        case 2:
            *ppu_status &= ~0x80;
            addrLatch = false;
            return status;
        case 4:
            return *oam_data;
        case 7:
            // TODO: delayed read buffer behavior
            if (*ppu_ctrl & 0x04)
                vramAddress += 32;
            else
                vramAddress += 1;

            vramAddress &= 0x3FFF;

            return *ppu_data;
        default:
            return 0x00;
        }
    }

    void write(uint16_t addr, uint8_t value)
    {
        uint16_t reg = (addr - 0x2000) % 8;
        switch (reg)
        {
        case 0: // PPUCTRL
            *ppu_ctrl = value;
            break;
        case 1: // PPUMASK
            *ppu_mask = value;
            break;
        case 2: // PPUSTATUS
            return;
            break;
        case 3:
            *oam_addr = value;
            break;
        case 4:
            *oam_data = value;
            break;
        case 5:
            // TODO
            break;
        case 6:
            // TODO
            printf("PPUADDR write: value = 0x%02X, addrLatch = %d, tempVramAddress = 0x%04X, vramAddress = 0x%04X\n", value, addrLatch, tempVramAddress, vramAddress);

            if (!addrLatch)
            {
                tempVramAddress = ((value & 0x3F) << 8) | (tempVramAddress & 0x00FF);
                tempVramAddress &= 0x3FFF;  // Clear bits 14 and 15
                addrLatch = true;
            }
            else
            {
                tempVramAddress = (tempVramAddress & 0xFF00) | value;
                tempVramAddress &= 0x3FFF;  // Clear bits 14 and 15
                vramAddress = tempVramAddress;
                addrLatch = false;
            }
            break;
        case 7:
            printf("PPUDATA write: addr=0x%04X, value=0x%02X\n", vramAddress, value);

            // Write data to VRAM at current address
            if (vramAddress < 0x2000)
                // Pattern table 0
                pattern_tables[vramAddress] = value;
            else if (vramAddress >= 0x2000 && vramAddress < 0x3000)
                // Nametables
                nametables[vramAddress - 0x2000] = value;
            else if (vramAddress >= 0x3000 && vramAddress < 0x3F00)
            {
                // Mirror of nametables
                uint16_t mirrorAddr = vramAddress - 0x3000;
                uint16_t nametableAddr = mirrorAddr + 0x1000; // Same offset, but offset relative to 0x2000

                // Mirror 0x3000-0x3EFF to 0x2000-0x2EFF
                nametables[nametableAddr] = value;
            }
            else if (vramAddress >= 0x3F00 && vramAddress < 0x4000)
            {
                // Palette
                uint16_t paletteAddr = 0x3F00 + (vramAddress % 32);
                palette[paletteAddr - 0x3F00] = value;
            }

            if (*ppu_ctrl & 0x04)
                vramAddress += 32;
            else
                vramAddress += 1;

            vramAddress &= 0x3FFF; // Wrap to 14 bits
            break;
        }
    }

    void drawNametable(uint32_t* framebuffer, const uint8_t* patternTables, const uint8_t* nametables, const uint8_t* paletteRAM) {
        // Determine which pattern table to use (PPUCTRL bit 4)
        const bool usePatternTable1 = (*ppu_ctrl & ppu_ctrl_flags::B) != 0;
        const uint8_t* activePatternTable = usePatternTable1 ? patternTables + 0x1000 : patternTables;

        for (uint16_t row = 0; row < 30; ++row) {
            for (uint16_t col = 0; col < 32; ++col) {
                // Get the tile index (0-255) from the nametable
                const uint16_t tileIndex = nametables[row * 32 + col];
                const uint8_t* tile = &activePatternTable[tileIndex * 16]; // Each tile is 16 bytes

                // Get the correct palette from the attribute table
                const uint16_t attrTableIndex = 0x3C0 + (row / 4) * 8 + (col / 4);
                const uint8_t attrByte = nametables[attrTableIndex];

                // Determine which 2 bits to use for this 2x2 tile block
                const uint8_t quadrantRow = (row % 4) / 2;
                const uint8_t quadrantCol = (col % 4) / 2;
                const uint8_t shift = (quadrantRow * 2 + quadrantCol) * 2;
                const uint8_t paletteIndex = (attrByte >> shift) & 0x03;

                // Render the 8x8 tile
                for (uint8_t y = 0; y < 8; ++y) {
                    const uint8_t plane0 = tile[y];       // Low bitplane
                    const uint8_t plane1 = tile[y + 8];   // High bitplane

                    for (uint8_t x = 0; x < 8; ++x) {
                        const uint8_t bit0 = (plane0 >> (7 - x)) & 1;
                        const uint8_t bit1 = (plane1 >> (7 - x)) & 1;
                        uint8_t colorIndex = (bit1 << 1) | bit0;

                        // If colorIndex == 0, use universal background (palette[0])
                        // Otherwise, use the selected palette
                        if (colorIndex == 0) {
                            colorIndex = paletteRAM[0]; // Background color
                        }
                        else {
                            colorIndex = paletteRAM[0x10 + (paletteIndex * 4) + colorIndex];
                        }

                        // Clamp to NES palette range (0-63)
                        colorIndex &= 0x3F;

                        // Calculate screen position
                        const uint16_t screenX = col * 8 + x;
                        const uint16_t screenY = row * 8 + y;

                        // Only draw if within bounds (some games use overscan)
                        if (screenX < 256 && screenY < 240) {
                            framebuffer[screenY * 256 + screenX] = nes_palette[colorIndex];
                        }
                    }
                }
            }
        }
    }
}